package com.cognizant.QEA25QE028.Selenium.EventListenersAndReports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.cognizant.QEA0250QE28.Utilities.ConfigLoader;

public class ProjectReportsClass {
	
	
	public static ExtentReports reports;
	public static ExtentTest test;
	
	ConfigLoader cfl = new ConfigLoader();
	
	
	public static void createAReport() {
		reports = new ExtentReports();
		
//		ExtentSparkReporter spark = new ExtentSparkReporter("projectResourcesOutputs/reportProjectEventListener.html");
		
		ExtentSparkReporter spark = new ExtentSparkReporter(ConfigLoader.getReportsFilePath());
		
		reports.attachReporter(spark);
	}
	
	public static void createTest(String name) {
		test = reports.createTest(name);
	}
	
	public static void endReport() {
		reports.flush();
	}
	
	
	
	
	
}